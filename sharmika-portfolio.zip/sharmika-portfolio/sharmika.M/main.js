var typed = new Typed(".text",{
    strings:["Frontend Developer","Web developer", "Java Developer", "software developer"],
    typeSpeed : 10,
    backSpeed : 100,
    backDelay : 1000,
    loop : true
});